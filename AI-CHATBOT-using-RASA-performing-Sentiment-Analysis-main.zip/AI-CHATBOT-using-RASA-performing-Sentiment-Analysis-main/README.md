# AI-CHATBOT-using-RASA-performing-Sentiment-Analysis

Hello Everyone,

Mental Health is an indicator of the emotional, psychological, and social well-being of an individual. A positive state of mind helps improve productivity and use the greater potential of a person. With an increasing number of mental health issues, it is important to check on one’s mental health regularly. Most people suffering from mental health problems isolate themselves and hide their emotions. The idea proposed aims to provide support to the user by checking on him/her regularly and not letting them alone through the user’s conversation analysis and a chatbot. The proposed idea includes a chatbot that provides feedback based on the analysis performed. The chatbot behaves like a close friend and interacts with the user. The chatbot engages the user in positive talks and suggests him/her favorite hobbies and activities. The application can help many people share their emotions with a human-like chatbot and improve their state of mind in general through sentiment analysis of their conversations.

Thank You
